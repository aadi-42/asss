package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class HotelDAOImpl implements IHotelDAO {
	
	

	@Override
	public List<Hotel> listHotels() throws HMSException {
		List<Hotel> hotelList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_HOTELS);) {

			ResultSet rs = st.executeQuery();

			hotelList = new ArrayList<Hotel>();
			
			while (rs.next()) {
				
				Hotel hotel = new Hotel();
				hotel.setHotelId(rs.getInt(1));
				hotel.setCity(rs.getString(2));
				hotel.setHotelName(rs.getString(3));
				
				hotelList.add(hotel);
			}

			if (hotelList.size() == 0)
				hotelList = null;
		} catch (SQLException e) {
			e.printStackTrace(); // remove this later
			throw new HMSException("Unable To Fetch Hotels");
		}
		return hotelList;
	}
}
