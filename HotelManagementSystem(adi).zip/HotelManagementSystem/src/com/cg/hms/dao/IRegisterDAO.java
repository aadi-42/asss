package com.cg.hms.dao;

import com.cg.hms.bean.User;

public interface IRegisterDAO {

	String saveUser();

}
