package com.cg.hms.dao;

import com.cg.hms.bean.User;

public class RegisterDAOImpl implements IRegisterDAO {

	@Override
	public static String saveUser() {
		// TODO Auto-generated method stub
		return null;
	}

}
