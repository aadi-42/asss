package com.cg.hms.ui;

import java.util.Scanner;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.IHotelService;
import com.cg.hms.service.IUserService;

public class RegisterUser {

	private Scanner scan;
	private String currentUser;
	IUserService userService;

	public void addUser() {

		User user = new User();
		System.out.print("Username: ");
		user.setUserName(scan.next());
		System.out.print("Password: ");
		user.setPassword(scan.next());
		try {
			String bcode = userService.saveUser(user);
			if (bcode == null)
				System.err.println("Operation Failed!");
			else
				System.out.println("User " + user.getUserName() + "Saved! ");
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}

}
