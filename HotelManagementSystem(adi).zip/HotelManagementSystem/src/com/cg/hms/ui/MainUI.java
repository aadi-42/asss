package com.cg.hms.ui;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.service.IHotelService;
import com.cg.hms.service.HotelServiceImpl;
import com.cg.hms.dao.IHotelDAO;
import com.cg.hms.exception.HMSException;
import com.cg.hms.dao.HotelDAOImpl;
import com.cg.hms.bean.Hotel;
import com.cg.hms.service.IUserService;
import com.cg.hms.service.UserServiceImpl;
import com.cg.hms.ui.RegisterUser;

public class MainUI {

	public static void main(String[] args) throws HMSException {
		Scanner scan = new Scanner(System.in);
		PropertyConfigurator.configure("res/log4j.properties");

		int choice = -1;

		int loginAttempts = 0;
		IUserService userService = new UserServiceImpl();

		while (choice != 3 && loginAttempts <= 3) {
			System.out.print("[1]SignIn [2]SignUp [3]Quit >");
			choice = scan.nextInt();

			if (choice == 1) {
				System.out.print("UserName? ");
				String userName = scan.next();
				System.out.print("Password? ");
				String password = scan.next();
				loginAttempts++;

				try {
					String role = userService.getRole(userName, password);
					System.out.println(role);
					if ("admin".equals(role)) {
						AdminConsole ac = new AdminConsole(userName);
						ac.start();
					} else {
						CustomerConsole sc = new CustomerConsole(userName);
						sc.start();
					}
				} catch (HMSException e) {
					System.err.println(e.getMessage());
				}

			}
			
		if (choice == 2){
			System.out.println("Welcome to SignUp Page");
			RegisterUser ac = new RegisterUser();
			ac.addUser();
		}	
		}
		scan.close();
	}
}