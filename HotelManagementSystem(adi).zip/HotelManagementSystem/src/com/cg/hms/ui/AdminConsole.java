package com.cg.hms.ui;

import com.cg.hms.service.IHotelService;

public class AdminConsole {
	
	private String currentUser;

	public AdminConsole(String currentUser) {
		this.currentUser = currentUser;
	}
	
	public void start() {
		System.out.println("Admin Console");
	}

}
