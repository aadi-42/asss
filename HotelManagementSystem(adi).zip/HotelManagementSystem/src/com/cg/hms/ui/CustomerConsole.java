package com.cg.hms.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.hms.service.HotelServiceImpl;
import com.cg.hms.service.IHotelService;
import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;

public class CustomerConsole {

	private Scanner scan;
	private String currentUser;
	IHotelService hotelService;

	public CustomerConsole(String currentUser) {
		this.currentUser = currentUser;
	}

	public void start() {
		scan = new Scanner(System.in);
		hotelService = new HotelServiceImpl();
		// dtFormat = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		System.out.println("Welcome " + currentUser);

		int choice = -1;

		while (choice != 2) {

			System.out.println("[1]Book Hotel [2]LogOut");
			System.out.print("Choice> ");
			choice = scan.nextInt();

			switch (choice) {
			case 1:
				reserveHotel();
				break;
			}

		}
	}

	public void reserveHotel() {
		try {
			List<Hotel> hotels = hotelService.listHotels();
			if (hotels != null) {
				System.out.println("\tHotel Id\tHotel Name\tCity");
				System.out.println("-----------------------------------------");
				for (Hotel hotel : hotels) {
					System.out.println(hotel.getHotelId()
							+ hotel.getHotelName() + hotel.getCity());
				}
			}
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}

	}
}
