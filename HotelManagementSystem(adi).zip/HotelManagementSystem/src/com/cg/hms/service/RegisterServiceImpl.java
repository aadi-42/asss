package com.cg.hms.service;

public class RegisterServiceImpl implements IRegisterService{

}
