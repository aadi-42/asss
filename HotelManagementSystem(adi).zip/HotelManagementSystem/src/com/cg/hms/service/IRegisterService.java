package com.cg.hms.service;

public interface IRegisterService {

}
