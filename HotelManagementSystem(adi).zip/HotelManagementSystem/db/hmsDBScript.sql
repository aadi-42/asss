
//Create User Table
CREATE TABLE users (userId varchar(4) PRIMARY KEY, 
password varchar(7),
role varchar(10), 
userName varchar(20) UNIQUE,
mobileNo varchar(10),
phone varchar(10),
address varchar(25), 
email varchar(15));

//Create Hotel Table
CREATE TABLE hotel (hotelId varchar(4),
city varchar(10),
hotelName varchar (20),
address varchar(25),
description varchar(50),
avgRatePerNight number(5,2),
phoneNo1 varchar(10),
phoneNo2 varchar(10),
rating varchar(6),
email varchar(15),
fax varchar(15));

//Create RoomDetails Table
CREATE TABLE roomdetails (hotel_id varchar(4), 
room_id varchar(4), 
room_no varchar(3),
room_type varchar(20),
per_night_rate number(6,2),
availability varchar(4));

//Create BookingDetails Table
CREATE TABLE bookingdetails (booking_id varchar(4),
room_id varchar(4),
user_id varchar(4),
booked_from date,
booked_to date,
no_of_adults number(3),
no_of_children number(3),
amount number(6,2));

//Insert into Hotel Table
INSERT INTO Hotel (hotelId, hotelName, city) values ('1001','Marriot','Bangalore');
INSERT INTO Hotel (hotelId, hotelName, city) values ('1002','TAJ','Mumbai');
INSERT INTO Hotel (hotelId, hotelName, city) values ('1003','Trident','Mumbai');

//Insert into Users
INSERT INTO users (userId, userName, password, role) values ('101','Admin','admin','admin');
INSERT INTO users (userId, userName, password, role) values ('102','Customer','cust','customer');
INSERT INTO users (userId, userName, password, role) values ('103','Employee','empl','employee');
