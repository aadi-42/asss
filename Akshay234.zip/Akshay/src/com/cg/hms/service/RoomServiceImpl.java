package com.cg.hms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.dao.IRoomDAO;
import com.cg.hms.dao.RoomDAOImpl;
import com.cg.hms.exception.HMSException;

@Service
public class RoomServiceImpl implements IRoomService {
	
@Autowired	
private IRoomDAO roomDao;
	
	public RoomServiceImpl() {
		roomDao = new RoomDAOImpl();
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listRoom
		- Input Parameters	:	Integer hcode, String rtype
		- Return Type		:	List roomList
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	list rooms in the database calls dao method 
								listRoom(hcode, rtype)
	********************************************************************************************************/
	
	
	@Override
	public List<Room> listRoom(int hcode,String rtype) throws HMSException {
		List<Room> roomList = null;
		roomList = roomDao.listRoom(hcode,rtype);
		return roomList;
	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listUserName
		- Input Parameters	:	Integer hcode
		- Return Type		:	List userList
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	find user from the database based on booking details 
								calls dao method listUserName(hcode)
	********************************************************************************************************/	
	
	@Override
	public List<User> listUserName(int hcode) throws HMSException {
		List<User> userList = null;
		userList = roomDao.listUserName(hcode);
		return userList;
	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listBooking
		- Input Parameters	:	Integer hcode
		- Return Type		:	List bookingList
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	find list of bookings from the database in a particular hotel 
								calls dao method listBookings(hcode)
	********************************************************************************************************/	
	
	@Override
	public List<Booking> listBookings(int hcode) throws HMSException {
		
		List<Booking> bookingList = null;
		bookingList = roomDao.listBooking(hcode);
		return bookingList; 
	}
}
