package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Repository;

import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;


@Repository
@Transactional
public class UserDAOImpl implements IUserDAO {

	@PersistenceContext
	private EntityManager eManager;

	int status = 0;
	int userId = 0;
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	getUserByName
		- Input Parameters	:	String userName
		- Return Type		:	User object
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	fetch user details from the database
	********************************************************************************************************/

	@Override
	public User getUserByName(String userName) {
		User user = null;
		
		String sql="SELECT user from User user where userName = :name";
		TypedQuery<User> qry = eManager.createQuery(sql, User.class);
		qry.setParameter("name", userName);
		user = qry.getSingleResult();
		System.out.println(user);
		return user;
		
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	addUser
		- Input Parameters	:	User object
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	add user details to the database
	********************************************************************************************************/	
	
//	@Override
//	public int addUser(User newUser) throws HMSException {
		// TODO Auto-generated method stub

//		Connection conn = null;
//		PreparedStatement st = null;
//		PreparedStatement st1 = null;
//
//		try {
//
//			conn = DbUtil.getConnection();
//			st = conn.prepareStatement(IQueryMapper.INSERT_USER);
//			
//			st.setString(1, newUser.getPassword());
//			st.setString(2, newUser.getRole());
//			st.setString(3, newUser.getUserName());
//			st.setString(4, newUser.getMobileNo());
//			st.setString(5, newUser.getPhoneNo());
//			st.setString(6, newUser.getAddress());
//			st.setString(7, newUser.getEmail());
//
//			status = st.executeUpdate();
//
//			st1 = conn.prepareStatement(IQueryMapper.USER_ID_SEQUENCE);
//			ResultSet resultSet = st1.executeQuery();
//
//			if (resultSet.next()) {
//				userId = resultSet.getInt(1);
//			}
//
//			newUser.setUserId(userId);
//			
//			return status;
//
//		} catch (Exception e) {
//			throw new HMSException("Unable To Add Records");
//		} finally {
//			try {
//				conn.close();
//				st.close();
//				st1.close();
//			} catch (Exception e) {
//				throw new HMSException("Check username and Password.");
//			}
//
//		}
//
	@Override
	public boolean addUser(User newUser) {
		eManager.persist(newUser);
		System.out.println(newUser.getUserName());
		
		return false;
	
	}

}
