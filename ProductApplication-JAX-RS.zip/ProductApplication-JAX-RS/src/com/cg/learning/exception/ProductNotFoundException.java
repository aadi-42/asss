package com.cg.learning.exception;

public class ProductNotFoundException extends Exception {

	public ProductNotFoundException(String string) {
				super(string);
	}

}
