export class Employee{
    name:String;
    rating:Number;
    genre:String;

}