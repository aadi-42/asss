import { Injectable }      from '@angular/core';
import {Employee} from './employee';
import {Http,Response,Headers, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"
import { Movie } from "./app.movie";
//import "rxjs/add/operator/throw"
@Injectable()
export class EmployeeService{
   
    constructor(private http:Http) {
    
}
    
    getAllEmployee():Observable<Employee[]> 
{ return  this.http.get("http://localhost:8081/Movie/rest/movie/getall").
        map((response:Response)=><Employee[]>response.json())
        .catch(this.handleError);
    }
    handleError(error: Response){
        console.error(error);
        return Observable.throw(error);
    }
    
    
    
    getBooks(data:String): Observable<Employee[]> {
        console.log(data)
        return this.http
            .get('http://localhost:8081/MovieLab/rest/movie/'+data)
            .map((response:Response)=><Employee[]>response.json())
            .catch(this.handleError);
        }
        handleErrorDelete(error: Response){
            console.error(error);
            return Observable.throw(error);
        }
        
        
        addBook(movie:Movie): Observable<Employee[]> {
            let mov=JSON.stringify(movie);
            console.log("Input : "+mov);
            
            let cpHeaders = new Headers({'Content-type':'application/json'})
            let options = new RequestOptions({ headers: cpHeaders });
            console.log(options);
            return this.http
                .post('http://localhost:8081/MovieLab/rest/add/',mov, options)
                .map((response:Response)=><Employee[]>response.json())
                .catch(this.handleError);
            }
            handleErrorAdd(error: Response){
                console.error(error);
                return Observable.throw(error);
            }
            
            
    }
