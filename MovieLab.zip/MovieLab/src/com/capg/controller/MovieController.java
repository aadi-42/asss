package com.capg.controller;
import java.util.List;

//import com.capg.bean.*;





import javax.json.JsonObject;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Movie;
import com.capg.db.ProductDB;


@RestController
public class MovieController {
	

	@RequestMapping(value = "/movie/{genre}",method = RequestMethod.GET,headers="Accept=application/json")
	public List<Movie> getMovieDetails(@PathVariable("genre") String genre)
	{
		
		return ProductDB.getMovie(genre);
	}
	

	@RequestMapping(value ="/add/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public Movie createEmployee(@RequestBody Movie movie) {
		
		
		 ProductDB.addMovie(movie);
		
		return movie;
}
	
	
}
