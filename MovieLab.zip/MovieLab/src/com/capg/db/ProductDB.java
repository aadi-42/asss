package com.capg.db;

import java.util.ArrayList;
import java.util.List;

import com.capg.bean.Movie;

public class ProductDB {
	
	static List<Movie> productList = null;
	
	public static List<Movie> loadList() {
		return productList;
	}
	
	static {
		if(productList==null) {
			productList = new ArrayList<Movie>();
			productList.add(new Movie("Movie1",3.5,"Drama"));
			productList.add(new Movie("Movie2",3.1,"Fiction"));
			productList.add(new Movie("Movie3",4.5,"Fiction"));
			productList.add(new Movie("Movie4",3.5,"Satire"));
			productList.add(new Movie("Movie5",2.5,"Drama"));
			productList.add(new Movie("Movie6",1.5,"Drama"));
			productList.add(new Movie("Movie7",1.4,"Satire"));
			productList.add(new Movie("Movie8",3.5,"Fiction"));
			productList.add(new Movie("Movie9",3.7,"Drama"));
			productList.add(new Movie("Movie10",4.7,"Fiction"));
			
		}
	}
	
	
	
	public static void addList(Movie movie){
		
		
		
		productList.add(movie);
		
		System.out.println(productList);
		
		
		
	}
	
	

public static List<Movie> getMovie(String genre) {
	
	List<Movie> list = new ArrayList<>();
	
	for (Movie movie : productList) {
		
		if(movie.getGenre().equals(genre))
		{
			list.add(movie);
			
		}
		
	}
	
	
	
	
	return list;
	
}



public static void addMovie(Movie movie) {
	
	productList.add(movie);
}

	
	
}
