package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Grocery;
import com.cg.service.GroceryService;

@Controller
public class GroceryController {
	@Autowired
	private GroceryService gService;

	@RequestMapping("/addGrocery")
	public String showGroceryForm(Model model) {
		System.out.println("show groc form");
		List<String> catList = gService.getCategoryList();
		model.addAttribute("clist", catList);
		System.out.println(catList);
		model.addAttribute("grocery", new Grocery());
		return "addgrocery";
	}

	@RequestMapping("/submitGrocery")
	public String submitGrocery(
			@ModelAttribute("grocery")@Valid Grocery groc,
			BindingResult bindingResult, Model model) {
		System.out.println("submitting groc: " + groc);
		boolean hasError = bindingResult.hasErrors();
		System.out.println("has error: " + hasError);
		if(hasError) {
			List<String> catList = gService.getCategoryList();
			model.addAttribute("clist", catList);
			return "addgrocery";
		}
		else {	
		boolean success = gService.saveGrocery(groc);
		System.out.println("submitted groc: " + groc);
		if (success) {
			model.addAttribute("groc", groc);
			return "successAdd";
		}
	}
		return "failAdd";
	}
	@RequestMapping("/retreiveGrocery")
	public String getAllGrocery(Model model) {
		List<Grocery> grocList = gService.getAllGrocery();
		model.addAttribute("glist", grocList);
		System.out.println(grocList);
		return "showAllPage";
	}
	@RequestMapping("/deleteGrocery")
	public String deleteGrocery(@RequestParam("gid")int delId,  Model model) {
		System.out.println("deleting record with id: " + delId);
		boolean deleted = gService.deleteGrocery(delId);
		if(deleted)
		  return "deletesuccess";
		else
		  return "deletefail";
	}
	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception e) {
		//send email to Call center/DBA here with exception details
		ModelAndView mav = new ModelAndView();
		mav.addObject("err", e);
		mav.setViewName("dataError");
		return mav ;
	}

}
