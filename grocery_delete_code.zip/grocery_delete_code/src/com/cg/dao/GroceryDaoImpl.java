package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Category;
import com.cg.bean.Grocery;

@Transactional
@Repository
public class GroceryDaoImpl implements GroceryDao {

	@PersistenceContext
	private EntityManager eManager;

	@Override
	public List<String> getCategoryList() {
		String qry = "select cat.category from Category cat";
		TypedQuery<String> query = eManager.createQuery(qry, String.class);
		return query.getResultList();
	}

	@Override
	public boolean saveGrocery(Grocery groc) {
		boolean success = false;
		try {
			eManager.persist(groc);
			success = true;
		} catch (Exception e) {
			// log error
			e.printStackTrace(); // remove this later
		}
		return success;
	}

	@Override
	public List<Grocery> getAllGrocery() {
		String qry = "select groc from Grocery groc";
		TypedQuery<Grocery> query = eManager.createQuery(qry, Grocery.class);
		return query.getResultList();
	}

	@Override
	public boolean deleteGrocery(int delId) {
		boolean deleted = false;
		try {
			Grocery groc = eManager.find(Grocery.class, delId);
			System.out.println("deleting groc: " + groc);
			if (groc != null) {
				eManager.remove(groc);
				deleted = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return deleted;
	}

}
