package com.cg.hms.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.AdminServiceImpl;
import com.cg.hms.service.BookingServiceImpl;
import com.cg.hms.service.HotelServiceImpl;
import com.cg.hms.service.IAdminService;
import com.cg.hms.service.IBookingService;
import com.cg.hms.service.IHotelService;
import com.cg.hms.service.IRoomService;
import com.cg.hms.service.IUserService;
import com.cg.hms.service.RoomServiceImpl;
import com.cg.hms.service.UserServiceImpl;

public class CustomerConsole {
	private String currentUser;
	private IHotelService hotelService;
	private IRoomService roomService;
	private IBookingService bookingService;
	private IUserService userService;
	private IAdminService adminService;
	private Scanner scan;
	double perNightCost;
	int userId;

	public CustomerConsole(String currentUser) {
		this.currentUser = currentUser;
	}

	public void start() throws HMSException {
		scan = new Scanner(System.in);
		hotelService = new HotelServiceImpl();
		roomService = new RoomServiceImpl();
		userService = new UserServiceImpl();
		System.out.println("Welcome " + currentUser);
		try {
			Booking book = new Booking();
			userId = userService.getUserId(currentUser);
			
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}

		int choice = -1;

		while (choice != 2) {

			System.out.println("[1]Reserve Hotel [2]LogOut");
			System.out.print("Choice> ");
			choice = scan.nextInt();

			switch (choice) {
			case 1:
				reserveHotel();
				break;
			case 2:
				System.out.println("Logged Out");
				break;
				
			default:
				System.out.println("Select a valid option");
			}
		}
	}

	public void reserveHotel() throws HMSException {
		System.out.println("Reserve Hotel");
		List<Hotel> hotels;
		try {
			hotels = hotelService.listHotels();

			if (hotels != null) {
				System.out.println("\tHotel Id\tCity\t\tHotel Name\tDescription\t\tAverage Room Rate\tRating");
				System.out.println("-------------------------------------------------------------------------------------------------------------");
				for (Hotel hotel : hotels) {
					System.out.println(
							"\t" + hotel.getHotelId() + "\t\t" + hotel.getHotelName() + "\t" + hotel.getCity()
							+ "          " + hotel.getDescription()+"\t\t"+hotel.getAvgRatePerNight()
							+ "\t\t\t" + hotel.getRating());
				}
			} else {
				System.out.println("No Records Found!");
			}

			System.out.print("HotelCode>: \n");
			int hcode = scan.nextInt();
			
			System.out.print("Room Type>:" + "\n([1] AC,[2] Non-AC,[3] Delux AC)\n");
			String rtype="";
			int roomtype = scan.nextInt();
			if(roomtype==1)
				rtype="AC";
			else if(roomtype==2)
				rtype="Non-AC";
			else if(roomtype==3)
				rtype="Delux AC";
			else 
				System.out.println("Bad Input");
			if (rtype.matches("AC") || rtype.matches("Non-AC") || rtype.matches("Delux AC")) {
				List<Room> rooms = new ArrayList<Room>();

				//rooms = roomService.listRoom(hcode, rtype); 
				
				if (rooms != null) {
					System.out.println("\tHotel Id\tRoom Id\tRoom Type\tPer Night Price\tAvailability");
					System.out.println("-------------------------------------------------------------------------");
					for (Room room : rooms) {
						System.out.println("\t" + room.getHotelId() + "\t\t" + room.getRoomId() + "\t\t"
								+ room.getRoomType() + "\t\t" + room.getPerNightPrice() + "\t\t" + room.getAvailable());
					}
				} else {
					System.out.println("No Records Found!");
					return;
				}
				bookingInitials();
			} else
				System.out.println("PLease Select a Valid Option");
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (InputMismatchException e) {
			throw new HMSException("\nPlease Enter Digits (0-9) only.");
		}
	}

	public void bookingInitials() {

		int diffInDays = 0;

		Booking book = new Booking();
		bookingService = new BookingServiceImpl();
		adminService = new AdminServiceImpl();
		double bookId = Math.random();
		int bookingId = (int) (bookId * 1000);
		book.setBookingId(bookingId);
		book.setUserId(userId);
		Date fDate = null, tDate = null;
		System.out.print("Room Id>: ");
		int rcode;

		try {
			rcode = Integer.parseInt(scan.next());
			book.setRoomId(rcode);
			
			adminService.modifyRoomAvailability(rcode, "Res");
			
			System.out.print("From Date(dd/MM/yyyy):");
			String sFromDate = scan.next();
			fDate = new SimpleDateFormat("dd/MM/yyyy").parse(sFromDate);

			System.out.print("To Date(dd/MM/yyyy):");
			String sToDate = scan.next();

			tDate = new SimpleDateFormat("dd/MM/yyyy").parse(sToDate);

			if (tDate.compareTo(fDate) > 0) {
				diffInDays = (int) ((tDate.getTime() - fDate.getTime()) / (1000 * 60 * 60 * 24));
				System.out.println("STAY IN DAYS:" + diffInDays);
			} else {
				System.out.println("To date must be GREATER than From Date");
				return;
			}
			java.sql.Date fromDate = new java.sql.Date(fDate.getTime());
			java.sql.Date toDate = new java.sql.Date(tDate.getTime());
			book.setfDate(fromDate); 
			book.settDate(toDate); 
			System.out.print("No of Adults:");
			book.setAdults(scan.nextInt());
			System.out.print("No of Children:");
			book.setChild((scan.nextInt()));

			Room room = bookingService.findAmount(rcode);

			perNightCost = room.getPerNightPrice();

			double amountAdult = 0;
			double amountChild = 0;
			double amountTotal = 0;
			if (book.getAdults() % 2 == 0) {
				amountAdult = diffInDays * perNightCost * (book.getAdults() / 2);
			}

			if (book.getAdults() % 2 != 0) {
				amountAdult = diffInDays * perNightCost * ((book.getAdults() / 2) + 1);
			}

			if (book.getChild() % 2 == 0) {
				amountChild = diffInDays * (perNightCost / 2) * (book.getChild() / 2);
			}

			if (book.getChild() % 2 != 0) {
				amountChild = diffInDays * (perNightCost / 2) * ((book.getChild() / 2) + 1);
			}

			amountTotal = amountAdult + amountChild;
			book.setAmount(amountTotal);

			boolean bookTrue = bookingService.saveBooking(book);
			if (bookTrue) {
				System.out.println("Room is Booked for " + currentUser + ".Your amount is " + amountTotal + ".");
			} else {
				System.out.println("Try Again for Room Booking");
			}

		} catch (ParseException e) {
			System.err.println("Unable to parse the given data");
		} catch (NumberFormatException e) {
			System.err.println("Invalid Entry." + "\nEnter digits 0-9 only");
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (NullPointerException e){
			System.err.println("No Values to Display. Unable to Retrieve Data");
		}
	}
}