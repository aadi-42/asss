package com.cg.hms.test;

import static org.junit.Assert.assertNotNull;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hms.bean.Booking;
import com.cg.hms.dao.BookingDaoImpl;
import com.cg.hms.exception.HMSException;

public class BookingDaoImplTest {

	static BookingDaoImpl dao;
	static Booking book;

	@BeforeClass
	public static void initialize() {
		System.out.println("Testing DAO");
		dao = new BookingDaoImpl();
		book = new Booking();
	}

	/*******************************************************
	 * Test case for RoomBooking()
	 *******************************************************/
	@Test
	public void testRoomBooking() throws HMSException {

		assertNotNull(dao.saveBooking(book));

	}

	@AfterClass
	public static void destroy() {
		System.out.println("\nTest Ended");
		dao = null;
		book = null;
	}

}
