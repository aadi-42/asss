package com.cg.hms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.dao.BookingDaoImpl;
import com.cg.hms.dao.IBookingDao;
import com.cg.hms.exception.HMSException;

@Service
public class BookingServiceImpl implements IBookingService {

@Autowired
private IBookingDao bookingDao;
	
	public BookingServiceImpl() {
		bookingDao = new BookingDaoImpl();
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	saveBooking
		- Input Parameters	:	Booking object
		- Return Type		:	boolean status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	saving booking details in the database calls dao method addHotel(hotel)
	********************************************************************************************************/	
		
	
	@Override
	public boolean saveBooking(Booking book) throws HMSException {
		boolean status = false;
		status = bookingDao.saveBooking(book);
		return status;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listBookingDetailsByRoomid
		- Input Parameters	:	Integer roomid
		- Return Type		:	List booklist
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	retrieving booking details of particular room using roomId from the database
								calls dao method listBookingDetailsByRoomid(roomid)
	********************************************************************************************************/	

	@Override
	public List<Booking> listBookingDetailsByRoomid(int roomid) throws HMSException {
		List<Booking> booklist = null;
		booklist = bookingDao.listBookingDetailsByRoomid(roomid);  
		return booklist;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	findAmount
		- Input Parameters	:	Integer rcode
		- Return Type		:	Room object
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	fetch room rate details from the database calls dao method findAmount(rcode)
	********************************************************************************************************/


	@Override
	public Room findAmount(int rcode) throws HMSException {
		Room room = new Room();
		room = bookingDao.findAmount(rcode); 
		return room;
	}

}
