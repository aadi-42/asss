package com.cg.hms.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.bean.User;
import com.cg.hms.dao.IUserDAO;
import com.cg.hms.dao.UserDAOImpl;
import com.cg.hms.exception.HMSException;

@Service
public class UserServiceImpl implements IUserService {
	
	@Autowired
	private IUserDAO dao;

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	getRole
		- Input Parameters	:	String userName, String password
		- Return Type		:	String role
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	fetch role detail of user from the database 
								calls dao method getUserByName(userName)
	********************************************************************************************************/	
	
	@Override
	public String getRole(String userName, String password) {
		// TODO Auto-generated method stub
		String role = null;
		User user = dao.getUserByName(userName);
		if (!password.equals(user.getPassword())){
			return null;
		} else {
			role = user.getRole();
			return role;
			}
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	addUser
		- Input Parameters	:	User object
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	add user details to the database calls dao method addUser(newUser)
	********************************************************************************************************/	
	
	@Override
	public boolean addUser(User newUser){
		
		boolean status = false;
		if (newUser != null ) {
			status = dao.addUser(newUser);
			return status;
		}
		return status;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	getRole
		- Input Parameters	:	String userName
		- Return Type		:	Integer uid
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	fetch user Id of the user from the database 
								calls dao method getUserByName(userName)
	********************************************************************************************************/	
	
	@Override
	public int getUserId(String userName) throws HMSException {
		int uid;
		User user = dao.getUserByName(userName);
		if (user == null)
			throw new HMSException("No Such UserName");
		else
			uid = user.getUserId();
		return uid;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
	 - Function Name	:	isValidAddEnquiry
	 - Input Parameters	:	User object
	 - Return Type		:	boolean
	 - Throws			:  	HMSException
	 - Creation Date	:	
	 - Description		:	validates the Add User Query
	 ********************************************************************************************************/		
	
	@Override
	public boolean isValidAddEnquiry(User newUser) throws HMSException {

		ArrayList<String> validationErrors = new ArrayList<String>();
		
		//Validating User Name
		if (!isValidUserName(newUser.getUserName())) {
			validationErrors.add("Username Incorrectly Entered." + "\nUsername Must Start with an Alphabet"
					+ "\nUsername Should be of at Least 3 Characters\n");
		}
		
		//Validating User Password
		if (!isValidPassword(newUser.getPassword())) {
			validationErrors.add("Weak Password." + "\nPassword Must Contain one Numeric Value"
					+ "\nPassword Length Should be Minimum 5.\n");
		}
		
		//Validating User Address
		if (!isValidAddress(newUser.getAddress())) {
			validationErrors.add("Address Incorrectly Entered." + "\nAddress Cannot Be Empty."
					+ "\nAddress Should Contain Minimum 7 Characters.\n");
		}

		//Validating User Mobile No.
		if (!isValidMobileNo(newUser.getMobileNo())) {
			validationErrors.add("Mobile Number Incorrectly Entered." + "\nPlease Enter Digits (0-9) only."
					+ "\nMobile Number Should be of 10 digits and Start with digits 7,8,9\n");
		}

		//Validating User Phone No.
		if (!isValidPhoneNo(newUser.getPhoneNo())) {
			validationErrors.add("Phone Number Incorrectly Entered." + "\nPlease Enter Digits (0-9) only."
					+ "\nPhone Number Should Be Of 8 OR 10 digits\n");
		}
		
		//Validating User Email Id
		if (!isValidEmail(newUser.getEmail())) {
			validationErrors
					.add("Email ID Incorrectly Entered." + "\nPlease Enter A Valid Email ID." + "\nEg. abc@xyz.com\n");
		}

		//Printing Validation Statements
		if (!validationErrors.isEmpty()) {
			throw new HMSException(validationErrors + " ");
		}

		return true;
	}

	//Validation methods
	private boolean isValidEmail(String email) {

		String ePattern = "^(.+)@(.+)$";

		Pattern pattern = Pattern.compile(ePattern);

		if (pattern.matcher(email).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidPhoneNo(String phoneNo) {
		String pattern = "[0-9]{8,10}";

		if (phoneNo.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidMobileNo(String mobileNo) {
		String pattern = "[789][0-9]{9}";

		if (mobileNo.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidAddress(String address) {
		if (address.length()>7) {
			return true;
		}
		return false;
	}

	private boolean isValidPassword(String password) {
		String dPattern = "[A-Za-z0-9]{3,}"; 
		Pattern pattern = Pattern.compile(dPattern);

		if (pattern.matcher(password).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidUserName(String userName) {
		String pattern = "[A-Za-z]{3,}";
		if (userName.matches(pattern)) {
			System.out.println();
			return true;
		}
		return false;
	}

}
