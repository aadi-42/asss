package com.cg.hms.service;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;

public interface IUserService {

	String getRole(String userName, String password);
	
	boolean addUser(User newUser);

	boolean isValidAddEnquiry(User user) throws HMSException;

	int getUserId(String userName) throws HMSException;
}