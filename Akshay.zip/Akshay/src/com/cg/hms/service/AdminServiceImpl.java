package com.cg.hms.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.dao.IAdminDao;
import com.cg.hms.exception.HMSException;

@Transactional
@Service
public class AdminServiceImpl implements IAdminService {
//	IAdminDao adminDao = new AdminDaoImpl();
	@Autowired
	private IAdminDao adminDao;

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	addHotel
		- Input Parameters	:	Hotel object
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	adding hotel to the database calls dao method addHotel(hotel)
	 * @throws HMSException 
	********************************************************************************************************/	
	
	@Override
	public int addHotel(Hotel hotel) throws HMSException  {

		int status = 0;
		if (hotel != null) {
			status = adminDao.addHotel(hotel);
			return status;
		}
		return status;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	modifyHotel
		- Input Parameters	:	Integer hotelId, String desc
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	modifying hotel present in the database calls dao method 
								modifyHotel(hotelId, desc)
	********************************************************************************************************/
		
	@Override
	public int modifyHotel(int hotelId, String desc) throws HMSException {

		int status = 0;
		if (isValidUpdateEnquiry(desc)) {
			status = adminDao.modifyHotel(hotelId, desc);
			return status;
		}
		return status;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	deleteHotel
		- Input Parameters	:	Integer hotelId
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	deleting hotel from the database calls dao method deleteHotel(hotelId)
	********************************************************************************************************/
	
	
	@Override
	public int deleteHotel(int hotelId) throws HMSException {
		
		int status = 0;
		if (isValidDeleteEnquiry(hotelId)) {
			status = adminDao.deleteHotel(hotelId);
			return status;
		}
		return status;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	addRoom
		- Input Parameters	:	Room object
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	adding room to the database calls dao method addRoom(room)
	********************************************************************************************************/
	
	
	@Override
	public int addRoom(Room room) throws HMSException {
		int status = 0;
		status = adminDao.addRoom(room);
		return status; 
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	modifyRoomAvailability
		- Input Parameters	:	Integer roomId, String value
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	modifying room availability in the database calls dao method
								modifyRoomAvailability(roomId, value)
	********************************************************************************************************/	
	
	@Override
	public int modifyRoomAvailability(int roomId, String value) throws HMSException {
		int status = 0;
		status = adminDao.modifyRoomAvailability(roomId, value);
		return status;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	deleteRoom
		- Input Parameters	:	Integer roomId
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	deleting room from the database calls dao method deleteRoom(roomId)
	********************************************************************************************************/
	
	
	@Override
	public int deleteRoom(int roomId) throws HMSException {
		
		int status = 0;
		status = adminDao.deleteRoom(roomId);
		return status;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	modifyRoomRate
		- Input Parameters	:	Integer roomId, String value
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	modifying room rate in the database calls dao method 
								modifyRoomRate(roomId, value)
	********************************************************************************************************/	
	
	@Override
	public int modifyRoomRate(int roomId, int value) throws HMSException {
		int status = 0;
		status = adminDao.modifyRoomRate(roomId, value);
		return status; 

	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
	 - Function Name	:	isValidAddEnquiry
	 - Input Parameters	:	Hotel object
	 - Return Type		:	boolean
	 - Throws			:  	HMSException
	 - Creation Date	:	
	 - Description		:	validates the Add Hotel Query
	 ********************************************************************************************************/	

	@Override
	public boolean isValidAddEnquiry(Hotel hotel) throws HMSException {

		ArrayList<String> validationErrors = new ArrayList<String>();

		//Validating Hotel Id
		if (!isValidHotelId(hotel.getHotelId())) {
			validationErrors.add("Hotel ID Incorrectly Entered." + "\nPlease Enter Digits (0-9) only."
					+ "\nHotel ID should be of 3 to 5 digits only\n");
		}
		
		//Validating Hotel Name
		if (!isValidHotelName(hotel.getHotelName())) {
			validationErrors.add("Hotel Name Incorrectly Entered." + "\nPlease Enter Characters (A-Z) only."
					+ "\nHotel Name Should Contain Minimum 3 Characters.\n");
		}
		
		//Validating Hotel City
		if (!isValidCity(hotel.getCity())) {
			validationErrors.add("City Name Incorrectly Entered." + "\nPlease Enter Characters (A-Z) only."
					+ "\nCity Name Should Contain Minimum 3 Characters.\n");
		}
		
		//Validating Hotel Description
		if (!isValidDescription(hotel.getDescription())) {
			validationErrors.add("Description Cannot Be Empty." + "\nShould Contain Minimum 5 Characters.\n");
		}
		
		//Validating Hotel Rating
		if (!isValidRating(hotel.getRating())) {
			validationErrors.add(
					"Rating Cannot Be Empty." + "\nPlease Enter Digits (1-5) only." + "\n 1- Lowest and 5- Highest\n");
		}

		//Validating Hotel Rate
		if (!isValidAvgRatePerNight(hotel.getAvgRatePerNight())) {
			validationErrors.add("Rate Cannot Be Empty." + "\nPlease Enter Digits (0-9) only.\n");
		}

		if (!isValidAddress(hotel.getAddress())) {
			validationErrors.add("Address Incorrectly Entered." + "\nAddress Cannot Be Empty."
					+ "\nAddress Should Contain Minimum 7 Characters.\n");
		}
		
		//Validating Hotel Phone Number
		if (!isValidPhoneNo1(hotel.getPhoneNo1())) {
			validationErrors.add("Phone Number Incorrectly Entered." + "\nPlease Enter Digits (0-9) only."
					+ "\nPhone Number Should Be Of 8 OR 10 digits\n");
		}

		//Validating Hotel Phone Number
		if (!isValidPhoneNo2(hotel.getPhoneNo2())) {
			validationErrors.add("Phone Number Incorrectly Entered." + "\nPlease Enter Digits (0-9) only."
					+ "\nPhone Number Should Be Of 8 OR 10 digits\n");
		}
		
		//Validating Hotel Email Id
		if (!isValidEmail(hotel.getEmail())) {
			validationErrors
					.add("Email ID Incorrectly Entered." + "\nPlease Enter A Valid Email ID." + "\nEg. abc@xyz.com\n");
		}

		
		//Validating Hotel Fax Number
		if (!isValidFax(hotel.getFax())) {
			validationErrors.add("Fax Number Incorrectly Entered." + "\nPlease Enter Digits (0-9) only."
					+ "\nFax Number Should Be Of 8 digits\n");
		}

		//Printing Validation Statements
		if (!validationErrors.isEmpty()) {
			throw new HMSException(validationErrors + " ");
		}

		return true;
	}

	// ----------------------------------1.HotelManagementSystem-----------------------------------------
	/*******************************************************************************************************
	 * Function Name	: isValidDeleteEnquiry
	 * Input Parameters : Integer hotelId
	 * Return Type		: Boolean 
	 * Throws 			: HMSException 
	 * Creation Date 	:
	 * Description 		: Validates the Delete Hotel Query
	 ********************************************************************************************************/

	@Override
	public boolean isValidDeleteEnquiry(int hotelId) throws HMSException {

		if (!isValidHotelId(hotelId)) {
			throw new HMSException("Hotel ID Incorrectly Entered." + "\nPlease Enter Digits (0-9) only.");
		}

		return true;
	}

	// ----------------------------------1.HotelManagementSystem-----------------------------------------
	/*******************************************************************************************************
	 * Function Name	: isValidUpdateEnquiry
	 * Input Parameters : String desc 
	 * Return Type 		: Boolean 
	 * Throws 			: HMSException 
	 * Creation Date 	:
	 * Description 		: Validates the Update Hotel Query
	 ********************************************************************************************************/

	@Override
	public boolean isValidUpdateEnquiry(String desc) throws HMSException {

		ArrayList<String> validationErrors = new ArrayList<String>();

		if (!isValidDescription(desc)) {
			validationErrors.add("Description Cannot Be Empty." + "\nShould Contain Minimum 3 Characters.");
		}

		if (!validationErrors.isEmpty()) {
			throw new HMSException(validationErrors + " ");
		}

		return true;
	}

	//Validation methods
	private boolean isValidFax(String fax) {
		String pattern = "[0-9]{8}";

		if (fax.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidEmail(String email) {

		String ePattern = "^(.+)@(.+)$";

		Pattern pattern = Pattern.compile(ePattern);

		if (pattern.matcher(email).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidPhoneNo2(String phoneNo2) {
		String pattern = "[0-9]{8,10}";

		if (phoneNo2.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidPhoneNo1(String phoneNo1) {
		String pattern = "[0-9]{8,10}";

		if (phoneNo1.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidAddress(String address) {

		if (address.length() > 5) {
			return true;
		}
		return false;
	}

	private boolean isValidAvgRatePerNight(double avgRatePerNight) {
		String rPattern = "\\d+\\.\\d+";
		Pattern pattern = Pattern.compile(rPattern);
		String rate = Double.toString(avgRatePerNight);

		if (pattern.matcher(rate).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidRating(String rating) {
		String pattern = "[1-5]{1}";

		if (rating.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidDescription(String description) {

		if (description.length() > 5) {
			return true;
		}
		return false;
	}

	private boolean isValidCity(String city) {
		String pattern = "[A-Za-z]{3,}";
		if (city.matches(pattern)) {
			System.out.println();
			return true;
		}
		return false;
	}

	private boolean isValidHotelName(String hotelName) {
		String pattern = "[A-Za-z]{3,}";
		if (hotelName.matches(pattern)) {
			System.out.println();
			return true;
		}
		return false;
	}

	private boolean isValidHotelId(int hotelId) {
		String pattern = "[0-9]{3,5}";

		String hid = Integer.toString(hotelId);

		if (hid.matches(pattern)) {
			return true;
		}
		return false;
	}

	@Override
	public void justTest() throws HMSException {
		adminDao.justTest();
	}

}
