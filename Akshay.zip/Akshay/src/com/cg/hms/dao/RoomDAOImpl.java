package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

@Transactional
@Repository
public class RoomDAOImpl implements IRoomDAO {
	@PersistenceContext
	private EntityManager eManager;
	
	private Logger log = Logger.getLogger("RoomDAO");
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listRoom
		- Input Parameters	:	Integer hcode, String rtype
		- Return Type		:	List roomList
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	list rooms in the database based on the room type 
								and availability in a particular hotel
	********************************************************************************************************/

	@Override
	public List<Room> listRoom(int hcode, String rtype) {
		System.out.println("reached list rooms");
		String sql="SELECT roomdetails from Room roomdetails where hotelId = :hcode And roomType =:rtype ";
		TypedQuery<Room> qry=eManager.createQuery(sql, Room.class);
		qry.setParameter("hid", hcode);
		qry.setParameter("rtype", rtype);
		List<Room> roomList = qry.getResultList();
		System.out.println(roomList);
		return roomList;
		
	}
//	@Override
//	public List<Room> listRoom(int hcode, String rtype) throws HMSException {
//		List<Room> roomList;
//		try (Connection conn = DbUtil.getConnection();
//				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_ROOMS);)  {
//			
//			st.setInt(1, hcode);
//			st.setString(2, rtype);
//			ResultSet rs = st.executeQuery();
//			roomList = new ArrayList<Room>();	
//			
//			log.info("Displaying Rooms in the database based on the Room type "
//					+ "and Availability in a particular Hotel");
//			
//			while(rs.next()){
//				Room room = new Room();
//				room.setHotelId(rs.getInt(1));
//				room.setRoomId(rs.getInt(2));
//				room.setRoomType(rs.getString(4));
//				room.setPerNightPrice(rs.getDouble(5));
//				room.setAvailable(rs.getString(6));
////				hotel.setStatus(Status.valueOf(rs.getString("status")));	
//				roomList.add(room);
//			}
//			
//		} catch (SQLException e) {
//			log.error("SQL ERROR IN FETCHING ROOM DATA FROM THE DATABASE");
//			throw new HMSException("Unable To Fetch roomdets");
//		}
//		if(roomList.isEmpty()){
//			roomList=null;
//			return roomList;
//		} else
//		return roomList;
//	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listUserName
		- Input Parameters	:	Integer hcode
		- Return Type		:	List userList
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	find user from the database based on booking details
	********************************************************************************************************/

	
	@Override
	public List<User> listUserName(int hcode) throws HMSException {
		List<User> userList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_USER);)  {
			st.setInt(1, hcode);
			ResultSet rs = st.executeQuery();
			
			userList = new ArrayList<User>();
			
			log.info("Finding User from the Database based on Booking details");
			
			while(rs.next()){
				User user = new User();
				user.setUserName(rs.getString("username"));
				userList.add(user);
			}
			
		} catch (SQLException e) {
			log.error("SQL ERROR IN FETCHING USER DATA FROM THE DATABASE");
			throw new HMSException("Unable To Fetch username");
		}
		return userList;
	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listBooking
		- Input Parameters	:	Integer hcode
		- Return Type		:	List bookingList
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	find list of bookings from the database in a particular hotel
	********************************************************************************************************/

	
	@Override
	public List<Booking> listBooking(int hcode) throws HMSException {
		List<Booking> bookingList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_BOOKING_DETAILS);)  {
			st.setInt(1, hcode);
			ResultSet rs = st.executeQuery();
			
			log.info("Searching List of Bookings from the Database in a particular Hotel");
			
			bookingList = new ArrayList<Booking>();
			while(rs.next()){
				Booking book = new Booking();
				
				book.setBookingId(rs.getInt("bookingid"));
				book.setRoomId(rs.getInt("roomid"));
				book.setUserId(rs.getInt("userid"));
				book.setfDate(rs.getDate("bookedFrom"));
				book.settDate(rs.getDate("bookedTo"));
				bookingList.add(book);
			}
			
		} catch (SQLException e) {
			log.error("SQL ERROR IN FETCHING BOOKING DATA FROM THE DATABASE");
			throw new HMSException("Unable To Fetch username");
		}
		return bookingList;
	}
	//Abhijeet
	@Override
	public boolean addRoom(Room newRoom) {
		eManager.persist(newRoom);
		System.out.println(newRoom.getRoomNo());
		return false;
	}

	@Override
	public int deleteRoom(int roomId) {
		System.out.println("IN delete Dao" + roomId);
		
		Room room = eManager.find(Room.class, roomId);
		System.out.println(room);
		eManager.remove(room);
		System.out.println(room);
		return 1;
		
	}

//	@Override
//	public int modifyRoom(int roomId) {
//		System.out.println("IN delete Dao" + roomId);
//		
//		Room room = eManager.find(Room.class, roomId);
//		eManager.merge(room.setAvailable("No"));
//		return 1;
//	}
}
