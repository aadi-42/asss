package com.cg.hms.dao;

import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;

public interface IRoomDAO {

	List<Room> listRoom(int hcode,String rtype);
	
	List<User> listUserName(int hcode) throws HMSException;
	
	List<Booking> listBooking(int hcode) throws HMSException;
	
	boolean addRoom(Room newRoom);

	int deleteRoom(int roomId);

//	int modifyRoom(int roomId);

//	List<Room> listRoom() throws HMSException;
}
