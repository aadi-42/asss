package com.cg.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.dao.IHotelDAO;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.IBookingService;
import com.cg.hms.service.IRoomService;
import com.cg.hms.service.IUserService;

@Controller
public class CustomerController {

	@Autowired
	public IHotelDAO adminService;

	@Autowired
	public IUserService userService;
	
	@Autowired
	public IBookingService bookService;
	
	@Autowired
	public IRoomService roomService;
	
	@RequestMapping("/Login")
	public String login(Model model) {

		model.addAttribute("obj", new User());

		return "LoginForm";
	}

	@RequestMapping("/HotelDetails")
	public String showHotelList(Model model) {
		System.out.println("show hotel list");
		List<Hotel> hotelList;
		try {

			hotelList = adminService.listHotels();
			model.addAttribute("hotelList", hotelList);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("okay exception");
		}
		return "HotelDetails";
	}

	@RequestMapping("/bookingroomtype")
	public String showHotelRoomType(@RequestParam("hid") String hid, @RequestParam("hname") String hname, Model model, HttpServletRequest request) {

		HttpSession session = request.getSession();
		session.setAttribute("hotelid", hid);
		
		// System.out.println("In booking hotel room");
		// List<Room> roomList;
		// try {
		// System.out.println("In try room");
		//roomList = adminService.listRoom();
		// System.out.println(roomList);
		// model.addAttribute("roomList", roomList);
		// System.out.println("done2");
		// } catch (Exception ex) {
		// ex.printStackTrace();
		// System.out.println("okay exception");
		// }

		return "type";
	}

	@RequestMapping("/bookinghotelroom")
	public String showHotelBookingForm(@RequestParam("type") String type, Model model, HttpServletRequest request) {

		/*System.out.println("In booking hotel room");
		List<Room> roomList;
		System.out.println("In try room");
		int hcode = Integer.parseInt(hid);
		String rtype = rtype;
		roomList = roomService.listRoom(hcode, rtype);
		System.out.println(roomList);
		model.addAttribute("roomList", roomList);
		System.out.println("done2");
		return "HotelBooking";
*/
		HttpSession session = request.getSession();
		String hid =  (String) session.getAttribute("hotelid");
		int hotelid = Integer.parseInt(hid);
		String rType = type; 
		System.out.println("com "+rType);
		 System.out.println("In booking hotel room");
				 List<Room> roomList;
				 try {
				roomList = adminService.listRoom(hotelid, rType);
				 System.out.println(roomList);
				 model.addAttribute("roomList", roomList);
				 System.out.println("done2");
				 } catch (Exception ex) {
				 ex.printStackTrace();
				 System.out.println("okay exception");}
				 return "HotelBooking";
	}

	@RequestMapping("/LoginDetails")
	public String loginDetails(@ModelAttribute User user) {

		String userName = user.getUserName();
		String password = user.getPassword();
		int loginAttempts = 0;
		loginAttempts++;

		String role = userService.getRole(userName, password);
		if ("admin".equals(role)) {
			System.out.println("Admin");
			return "AdminPage";
		} else {
			System.out.println("customer");
			return "CustomerPage";
		}

	}
	
	@RequestMapping("/bookingform")
	public String bookingform(@RequestParam("rid") int rid, @RequestParam("rate") double rate, Model model, HttpServletRequest request) {
		
		Booking book = new Booking();
		int roomid = rid;
		book.setRoomId(roomid);
		HttpSession session = request.getSession();
		session.setAttribute("id", roomid);
		session.setAttribute("rate", rate);
		

		model.addAttribute("obj", book);

		return "BookingForm";
	}
	
	@RequestMapping("/submitDetails")
	public String submitDetails(@ModelAttribute Booking book, Model model,
			HttpServletRequest request) throws HMSException {

		HttpSession session = request.getSession();
		int roomid = (int) session.getAttribute("id");
		double rate = (double) session.getAttribute("rate");


		int adults = book.getAdults();
		int child = book.getChild();

		double amnt = 0;

		if ((adults) % 2 == 0) {
			amnt = (rate * adults / 2);
		} else {
			amnt = (rate * ((adults / 2)+1));
		}
		System.out.println(amnt);
		book.setAmount(amnt);
		session.setAttribute("amount", amnt);
		book.setRoomId(roomid);
		double bid = Math.random();
		int bookid = (int) (bid*1000);
		book.setBookingId(bookid);
		book.setUserId(2187);
		bookService.saveBooking(book);

		return "confirm";
	}

	
	@RequestMapping("/signUp")
	public String signUp(Model model) {

		model.addAttribute("obj", new User());
		
		return "SignUpForm";
	}
	
	/*Modified Abhijeet*/
	@RequestMapping("/newUserDetails")
	public String addUserDetails(@ModelAttribute User user) {
		double uid = Math.random();
		int usrId = (int) (uid * 1000);
		user.setUserId(usrId);
		userService.addUser(user);
		System.out.println(user.getUserName());		
		return "CustomerPage";
	}

}
