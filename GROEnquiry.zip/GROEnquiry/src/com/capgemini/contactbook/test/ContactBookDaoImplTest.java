package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookDaoImplTest {

	public static ContactBookDaoImpl contactBookDaoImpl = new ContactBookDaoImpl();
	EnquiryBean enqry = new EnquiryBean();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@Test
	public void testAddEnquiry() throws ContactBookException {

		// enqry.setEnqryId(1007);
		enqry.setfName("Scarface");
		enqry.setlName("Leonard");
		enqry.setContactNo("8097881369");
		enqry.setpDomain("Java");
		enqry.setpLocation("Bengaluru");

		// assertNotNull(contactBookDaoImpl);
		assertEquals(1, contactBookDaoImpl.addEnquiry(enqry));

	}

	@Test
	public void testGetEnquiryDetails() throws ContactBookException {

		contactBookDaoImpl.getEnquiryDetails(1007);

		assertNotNull(enqry);
	}

}
