package com.capgemini.contactbook.ui;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class Client {

	public static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");

		Scanner in = new Scanner(System.in);
		int choice = 0;
		ContactBookServiceImpl enqryService = new ContactBookServiceImpl();
		do {
			System.out.println("\n*********ENQUIRY DETAILS TABLE*********");
			logger.info("Application started");
			System.out.println("Choose an operation:");
			System.out.println("1.Enter Enquiry Details");
			System.out.println("2.View Enquiry Details on Id");
			System.out.println("0.Exit");
			System.out.println("*****************************************");
			System.out.println("\nPlease Enter a choice: ");
			choice = in.nextInt();
			switch (choice) {
			case 1:

				System.out.println("Enter First Name: ");
				String fName = in.next();
				System.out.println("Enter Last Name: ");
				String lName = in.next();
				System.out.println("Enter Contact Number: ");
				String contactNo = in.next();
				System.out.println("Enter preferred Domain:");
				String pDomain = in.next();
				System.out.println("Enter Preferred Location");
				String pLocation = in.next();

				EnquiryBean enqry = new EnquiryBean();
				enqry.setfName(fName);
				enqry.setlName(lName);
				enqry.setContactNo(contactNo);
				enqry.setpDomain(pDomain);
				enqry.setpLocation(pLocation);

				try {
					enqryService.isValidEnquiry(enqry);
				} catch (ContactBookException e) {
					logger.error("Validation unsuccessful");
					System.err.println(e.getMessage() + " Please Try Again...");
					break;
				}

				logger.info("validation successful");
				try {
					int n = enqryService.addEnquiry(enqry);
					if (n > 0) {
						System.out.println("Thank You " + enqry.getfName()
								+ " " + enqry.getlName()
								+ " your Unique Id is " + enqry.getEnqryId()
								+ ". We will contact you shortly.");
						logger.info("Enquiry is added");
					} else {
						logger.error("Enquiry not added");
					}
				} catch (ContactBookException e) {
					logger.error("Adding enquiry unsuccessful");
					System.err.println("Adding enquiry unsuccessful");
				}
				break;
			case 2:
				EnquiryBean enqryBean;
				System.out.println("Enter Enquiry Id: ");
				int enqryId = in.nextInt();
				
				try {
					enqryService.isValidEnqryId(enqryId);
					logger.info("Id Validated");
				} catch (ContactBookException e1) {
					System.err.println(e1.getMessage() + " Please Try Again...");
					logger.error("Invalid Id Entered");
					break;
				}
				try {
					enqryBean = enqryService.getEnquiryDetails(enqryId);
					if (enqryBean == null) {
						logger.error("Enquiry Id does not exist in Enquiry DB");
						System.err.println("Sorry no details found!!");
						break;
					} else {
						System.out.println(enqryBean);
						logger.info("Details of Enquiry displayed");
						break;
					}
				} catch (ContactBookException e) {
					System.out.println(e.getMessage() + " ");
					logger.error(e.getMessage());
					break;
				}
			case 0:
				System.out.println("Thank You for selecting us!!");
				System.exit(0);
			default:
				break;
			}

		} while (choice != 0);

	}
}
