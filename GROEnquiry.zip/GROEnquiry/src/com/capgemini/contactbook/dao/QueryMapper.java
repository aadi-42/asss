package com.capgemini.contactbook.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY = "insert into ENQUIRY values(enquiries.nextval,?,?,?,?,?)";
	public static final String SELECT_QUERY = "select * from ENQUIRY where enqryId = ?";
	public static final String ENQUIRYID_QUERY="select enquiries.CURRVAL from DUAL";
	public static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	public static final String UNAME = "system";
	public static final String PASSWORD = "orcl11g";

}
