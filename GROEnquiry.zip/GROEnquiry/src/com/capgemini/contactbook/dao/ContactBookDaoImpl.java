package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookDaoImpl implements ContactBookDao {

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		Connection conn = DBUtil.getConnection();

		try {
			PreparedStatement pstat = conn
					.prepareStatement(QueryMapper.INSERT_QUERY);
			pstat.setString(1, enqry.getfName());
			pstat.setString(2, enqry.getlName());
			pstat.setLong(3, Long.parseLong(enqry.getContactNo()));
			pstat.setString(4, enqry.getpDomain());
			pstat.setString(5, enqry.getpLocation());

			int n = pstat.executeUpdate();
			pstat.close();
			PreparedStatement pstatgetid = conn
					.prepareStatement(QueryMapper.ENQUIRYID_QUERY);
			ResultSet res = pstatgetid.executeQuery();
			while (res.next()) {
				enqry.setEnqryId(res.getInt(1));
			}
			pstatgetid.close();
			return n;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enqryId)
			throws ContactBookException {
		Connection conn = DBUtil.getConnection();

		EnquiryBean enqryBean = new EnquiryBean();

		try {
			PreparedStatement pstat = conn
					.prepareStatement(QueryMapper.SELECT_QUERY);
			pstat.setInt(1, enqryId);
			ResultSet myRes = pstat.executeQuery();
			while (myRes.next()) {
				enqryBean.setEnqryId(myRes.getInt(1));
				enqryBean.setfName(myRes.getString(2));
				enqryBean.setlName(myRes.getString(3));
				enqryBean.setContactNo(String.valueOf(myRes.getLong(4)));
				enqryBean.setpDomain(myRes.getString(5));
				enqryBean.setpLocation(myRes.getString(6));
				return enqryBean;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
