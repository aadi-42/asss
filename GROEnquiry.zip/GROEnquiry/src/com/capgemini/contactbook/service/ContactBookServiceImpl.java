package com.capgemini.contactbook.service;

import java.util.ArrayList;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService {

	ContactBookDaoImpl contactBkDao = new ContactBookDaoImpl();

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		return contactBkDao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enqryId)
			throws ContactBookException {
		return contactBkDao.getEnquiryDetails(enqryId);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {

		ArrayList<String> validationErrors = new ArrayList<String>();

		if (!isValidfName(enqry.getfName())) {
			validationErrors
					.add("First Name Incorrectly Entered. Please enter atleast 3 Characters.");
		}
		if (!isValidlName(enqry.getlName())) {
			validationErrors
					.add("Last Name Incorrectly Entered. Please enter atleast 3 Characters.");
		}
		if (!isValidContactNo(enqry.getContactNo())) {
			validationErrors.add("Contact Number incorrectly Entered.");
		}
		if (!isValidpLocation(enqry.getpLocation())) {
			validationErrors.add("Preferred Location incorrectly Entered.");
		}
		if (!isValidpDomain(enqry.getpDomain())) {
			validationErrors.add("Preferred Domain incorrectly Entered.");
		}

		if (!validationErrors.isEmpty()) {
			throw new ContactBookException(validationErrors + " ");
		}

		return true;
	}

	public void isValidEnqryId(int enqryId) throws ContactBookException {
		if (!(enqryId > 1000 && enqryId < 9999))
			throw new ContactBookException("Invalid ID Entered! Enter Id between 1000 and 9999");
	}

	private boolean isValidpDomain(String pDomain) {
		String pattern = "[A-Za-z]{3,}";
		if (pDomain.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidpLocation(String pLocation) {
		String pattern = "[A-Za-z]{3,}";
		if (pLocation.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidContactNo(String contactNo) {
		String pattern = "[789][0-9]{9}";
		if (contactNo.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidfName(String fName) {
		String pattern = "[A-Za-z]{3,}";
		if (fName.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidlName(String lName) {
		String pattern = "[A-Za-z]{3,}";
		if (lName.matches(pattern)) {
			return true;
		}
		return false;
	}

}
